# An introduction to resilience4j
 Resilience4j has many features like- Circuit breaker, bulkhead, rate limiter, retry. It also potential replacement candidate for Netflix hystris. To have the complete understanding watch video - 
 
 https://youtu.be/Z_viIJSGXJw
 
 # Spring boot + resilience4j + Using annotations
 
 Below are the details about circuit breaker, bulkhead, retry and ratelimiter
 
 ## Circuit Breaker
 
* Part 1 of 3  - https://youtu.be/Q1KlqAD8-6s

* Part 2 of 3  -  https://youtu.be/rZWV23nzGdk

* Part 3 of 3  - https://youtu.be/VPvmP64VlMo

## Bulkhead

Explained in video - 

* https://youtu.be/ib_cL26zOB8

## Retry

Explained in video - 

* https://youtu.be/X7X2FXqPRaI

## Ratelimiter

Explained in video - 

* https://youtu.be/GvcKYTZvrMM

## Application Monitoring

I have explained micrometer, prometheus and Grafana. For full details watch below videos - 

* Part 1 of 2 - https://youtu.be/hOhHmnE9uXs

* Part 2 of 2 - https://youtu.be/eVIeYE5lYMs

