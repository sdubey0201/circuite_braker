package com.gl.orderManagementApp.service;

/**
 * @author - GreenLearner(https://www.youtube.com/channel/UCaH2MTg94hrJZTolW01a3ZA)
 */
public class MyException extends Exception{
    public MyException(String msg) {
        super(msg);
    }
}
